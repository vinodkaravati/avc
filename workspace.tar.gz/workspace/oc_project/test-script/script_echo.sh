#!/bin/bash
mysqlshow -u$MYSQL_USER -p$MYSQL_PASSWORD $MYSQL_DATABASE
