#!/bin/bash

echo "Populating characters table"
PGPASSWORD=redhat /usr/bin/psql -U candidate acmedb < /tmp/init_data.sql

echo "Printing the Test Table"
PGPASSWORD=redhat /usr/bin/psql -U candidate acmedb -c 'select id,name,nationality from characters'

echo "Test Passed"
