#!/bin/bash
export POD=$(oc get pods -l app=message-info -o custom-columns=POD:.metadata.name --no-headers)

