#!/bin/bash
###Deploy Mysql pod
