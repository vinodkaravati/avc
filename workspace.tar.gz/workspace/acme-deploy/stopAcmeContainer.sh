#!/bin/bash
##Stop and remove the container
