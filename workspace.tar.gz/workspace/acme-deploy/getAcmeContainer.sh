#!/bin/bash
##Get the logs of the container
